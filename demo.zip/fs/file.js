var fs=require("fs");

console.log("准备打开文件");

fs.open('input.txt','r+',function(err,fs)
	{
		if(err)
		{
			console.error(err);
		}

		console.log("文件打开成功")
	});
 
/*fs.readFile('input.txt',function(err,data){
	if(err)
	{
		return console.error(error);
	}
	
	console.log("异步读取" + data.toString());

});

var data=fs.readFileSync('input.txt');
console.log("同步读取 "+ data.toString());

console.log("程序执行完毕");*/