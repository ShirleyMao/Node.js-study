function route(pathname){
	console.log("about to route a request for "+ pathname);
}

exports.route=route;