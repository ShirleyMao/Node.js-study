var Hello= require('./hello');
var hello=new Hello;
hello.setName('MM');
hello.sayHello();