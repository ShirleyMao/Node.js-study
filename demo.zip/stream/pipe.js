var fs=require("fs");
var data='';

var readStream=fs.createReadStream('input.txt');

var writeStream=fs.createWriteStream('output.txt');

readStream.pipe(writeStream);

console.log("执行完毕");