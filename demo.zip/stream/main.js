var fs=require("fs");
var data='';

var readStream=fs.createReadStream('input.txt');
readStream.setEncoding('UTF8');

readStream.on('data',function(chunk){
	data+=chunk;
});

readStream.on('end',function(){
	console.log(data);
});

readStream.on('error',function(error){
	console.log(error.stack);
});

console.log("执行完毕");

var dataout='你好！hello world';

var writeStream=fs.createWriteStream('output.txt');

writeStream.write(dataout,'UTF8');

writeStream.end();

writeStream.on('finish',function(){
	console.log("写入完成");
});

writeStream.on('error',function(error){
	console.log(error.stack);
});

console.log("执行完毕");